package com.pluralsight.decorator;

public interface Sandwich {
	public String make();
}
