package com.pluralsight.visitorbad;

public interface AtvPart {
	public double calculateShipping();
}
