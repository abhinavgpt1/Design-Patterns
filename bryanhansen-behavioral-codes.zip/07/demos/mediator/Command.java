package com.pluralsight.mediator;

//colleague
public interface Command {
	void execute();
}
