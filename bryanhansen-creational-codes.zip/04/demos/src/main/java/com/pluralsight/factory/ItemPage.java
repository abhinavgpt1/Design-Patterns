package com.pluralsight.factory;

public class ItemPage extends Page {

}
