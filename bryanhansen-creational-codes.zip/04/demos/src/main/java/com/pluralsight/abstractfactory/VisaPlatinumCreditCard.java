package com.pluralsight.abstractfactory;

public class VisaPlatinumCreditCard extends CreditCard {

}
