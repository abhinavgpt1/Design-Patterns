package com.pluralsight.factory;

public class PostPage extends Page {

}
