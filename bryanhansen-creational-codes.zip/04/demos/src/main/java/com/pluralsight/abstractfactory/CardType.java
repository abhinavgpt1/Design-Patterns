package com.pluralsight.abstractfactory;

public enum CardType {
	GOLD, PLATINUM;
}
