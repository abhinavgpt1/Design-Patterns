package com.pluralsight.abstractfactory;

public class VisaGoldCreditCard extends CreditCard {

}
