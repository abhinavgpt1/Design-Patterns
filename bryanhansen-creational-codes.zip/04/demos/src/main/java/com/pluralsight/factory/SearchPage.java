package com.pluralsight.factory;

public class SearchPage extends Page {
}
